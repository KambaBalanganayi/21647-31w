<footer class="site__footer">
Le pied de page
</footer>
<?php wp_footer(); ?>
</section> <!-- fin .site -->
</body>
</html>