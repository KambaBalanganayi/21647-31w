# Exercice - 1
## Premier thème et plugin  Wordpress
### Contient 3 commits

[github-page](https://eddytuto.github.io/theme-31w)
> Le thème conient 5 fichiers:
index.php
style.css
functions.php
header.php
footer.php
readme.md

Pour plus d'information sur la conception de thème
[WP developper guide](https://developper.wordpress.org/theme)